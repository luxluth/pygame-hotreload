# SPDX-FileCopyrightText: 2023-present luxluth <delphin.blehoussi93@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.32"
